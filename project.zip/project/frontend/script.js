function upload() {
    let fileInput = document.getElementById("audioInput");
    if (fileInput.files.length === 0) {
        alert("請選擇音檔");
        return;
    }

    let formData = new FormData();
    formData.append("audio", fileInput.files[0]);

    fetch("http://localhost:5000/upload", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        document.getElementById("transcript").innerText = data.transcript;
        document.getElementById("explanation").innerText = data.explanation;

        let audio = document.getElementById("ttsAudio");
        audio.src = "http://localhost:5000/tts";
        audio.load();
        audio.play();
    });
}
