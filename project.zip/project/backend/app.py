from flask import Flask, request, jsonify, send_file, send_from_directory
from speech import process_audio
from flask_cors import CORS
import os

app = Flask(__name__, static_folder="../frontend", static_url_path="/")
CORS(app)

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/")
def home():
    # 回傳前端 index.html
    return send_from_directory("../frontend", "index.html")


@app.route("/upload", methods=["POST"])
def upload_audio():
    if "audio" not in request.files:
        return jsonify({"error": "No audio file uploaded"}), 400

    audio_file = request.files["audio"]
    filepath = os.path.join(UPLOAD_FOLDER, audio_file.filename)
    audio_file.save(filepath)

    text, explanation, audio_path = process_audio(filepath)

    return jsonify({
        "transcript": text,
        "explanation": explanation,
        "audio_url": "/tts"
    })


@app.route("/tts", methods=["GET"])
def get_tts():
    return send_file("explain.mp3", mimetype="audio/mpeg")


if __name__ == "__main__":
    app.run(port=5000, debug=True)
