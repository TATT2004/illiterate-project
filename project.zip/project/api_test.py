from openai import OpenAI

client = OpenAI(api_key="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")

response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[
        {"role": "user", "content": "你好，請簡單介紹你自己。"}
    ]
)

print(response.choices[0].message.content)
