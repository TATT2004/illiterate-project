import base64
import json
import requests

API_KEY = "AIzaSyCaXF4J28ZFAOPQBUbvdg_5lOzDjottoEU"   # <<< 在這裡放你的金鑰
AUDIO_FILE = "test.mp3"          # <<< 測試音檔


def speech_to_text():
    with open(AUDIO_FILE, "rb") as f:
        audio_content = base64.b64encode(f.read()).decode("utf-8")

    url = f"https://speech.googleapis.com/v1/speech:recognize?key={API_KEY}"

    body = {
        "config": {
            "encoding": "MP3",
            "languageCode": "zh-TW"
        },
        "audio": {
            "content": audio_content
        }
    }

    response = requests.post(url, json=body)
    print("回傳內容：")
    print(json.dumps(response.json(), indent=2, ensure_ascii=False))

if __name__ == "__main__":
    speech_to_text()
