import base64
import json
import requests

API_KEY = "AIzaSyCaXF4J28ZFAOPQBUbvdg_5lOzDjottoEU"   # <<< 在這裡放你的金鑰
OUTPUT_FILE = "output.mp3"


def text_to_speech(text="你好，這是 Google 文字轉語音測試！"):
    url = f"https://texttospeech.googleapis.com/v1/text:synthesize?key={API_KEY}"

    body = {
        "input": { "text": text },
        "voice": {
            "languageCode": "zh-TW",
            "ssmlGender": "NEUTRAL"
        },
        "audioConfig": {
            "audioEncoding": "MP3"
        }
    }

    response = requests.post(url, json=body)
    data = response.json()

    # 將 Base64 轉成音檔
    audio_content = base64.b64decode(data["audioContent"])

    with open(OUTPUT_FILE, "wb") as f:
        f.write(audio_content)

    print(f"音檔已輸出：{OUTPUT_FILE}")


if __name__ == "__main__":
    text_to_speech()
