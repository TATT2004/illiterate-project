import tkinter as tk
from tkinter import filedialog
import requests
import base64
import google.generativeai as genai
import os

# -------------------------
# API Keys
# -------------------------
GOOGLE_API_KEY = "YOUR_GOOGLE_API_KEY"
GEMINI_API_KEY = "YOUR_GEMINI_API_KEY"

genai.configure(api_key=GEMINI_API_KEY)


# ------------------------------------------------
# 選擇 MP3 並進行語音轉文字
# ------------------------------------------------
def choose_mp3():
    filepath = filedialog.askopenfilename(
        filetypes=[("MP3 files", "*.mp3"), ("All files", "*.*")]
    )
    if filepath:
        status_label.config(text="音檔讀取中...", fg="blue")
        transcribe_audio(filepath)


# ------------------------------------------------
# Google Speech-to-Text
# ------------------------------------------------
def transcribe_audio(filepath):
    with open(filepath, "rb") as f:
        audio_base64 = base64.b64encode(f.read()).decode("utf-8")

    url = f"https://speech.googleapis.com/v1/speech:recognize?key={GOOGLE_API_KEY}"

    # 這裡 encoding 要改成 MP3
    body = {
        "config": {
            "encoding": "MP3",
            "languageCode": "zh-TW"
        },
        "audio": {
            "content": audio_base64
        }
    }

    response = requests.post(url, json=body)
    result = response.json()
    print(result)

    try:
        text = result["results"][0]["alternatives"][0]["transcript"]
        result_label.config(text="語音辨識：" + text)

        # Gemini AI 解釋
        explain_text_gemini(text)

    except:
        result_label.config(text="辨識失敗，請使用較清晰的音檔")
        status_label.config(text="請選擇 mp3 檔案", fg="black")
        return


# ------------------------------------------------
# Gemini AI 解釋
# ------------------------------------------------
def explain_text_gemini(input_text):
    status_label.config(text="Gemini AI 解釋中...", fg="green")

    prompt = f"請用非常簡單、淺顯易懂的中文解釋這段話或這個詞語：{input_text}"

    try:
        model = genai.GenerativeModel("gemini-1.5-flash")
        response = model.generate_content(prompt)

        explanation = response.text
        explanation_label.config(text="AI 解釋：" + explanation)

        speak_text(explanation)

    except Exception as e:
        explanation_label.config(text="AI 解釋失敗：" + str(e))

    status_label.config(text="請選擇 mp3 檔案", fg="black")


# ------------------------------------------------
# Google TTS 播放
# ------------------------------------------------
def speak_text(text):
    url = f"https://texttospeech.googleapis.com/v1/text:synthesize?key={GOOGLE_API_KEY}"

    body = {
        "input": {"text": text},
        "voice": {"languageCode": "zh-TW", "ssmlGender": "NEUTRAL"},
        "audioConfig": {"audioEncoding": "MP3"}
    }

    response = requests.post(url, json=body)
    data = response.json()

    audio_data = base64.b64decode(data["audioContent"])

    with open("explain.mp3", "wb") as f:
        f.write(audio_data)

    os.system("start explain.mp3")  # Windows 播放


# ------------------------------------------------
# Tkinter UI
# ------------------------------------------------
root = tk.Tk()
root.title("MP3 語音轉文字 + Gemini 解釋 + TTS")
root.geometry("600x450")

status_label = tk.Label(root, text="請選擇 mp3 檔案", font=("Arial", 14))
status_label.pack(pady=10)

choose_btn = tk.Button(root, text="選擇 MP3 檔案", font=("Arial", 16), command=choose_mp3)
choose_btn.pack(pady=10)

result_label = tk.Label(root, text="語音辨識：", font=("Arial", 14), wraplength=550)
result_label.pack(pady=20)

explanation_label = tk.Label(root, text="AI 解釋：", font=("Arial", 14), wraplength=550, justify="left")
explanation_label.pack(pady=20)

root.mainloop()
